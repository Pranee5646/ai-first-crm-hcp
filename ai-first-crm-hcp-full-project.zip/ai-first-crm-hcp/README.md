# AI-First CRM — HCP Interaction Module

A full-stack AI-first CRM module for life-sciences field representatives. Users can log Healthcare Professional (HCP) interactions using either a structured form or a conversational AI assistant.

## Tech Stack

- Frontend: React + Vite + Redux Toolkit
- Backend: Python + FastAPI
- AI Agent: LangGraph
- LLM: Groq (`gemma2-9b-it` by default; configurable through `.env`)
- Database: PostgreSQL or MySQL via SQLAlchemy
- Font: Google Inter

## Five LangGraph Tools

1. **Log Interaction** — extracts structured interaction data from natural language, summarizes notes, and saves the record.
2. **Edit Interaction** — modifies an existing interaction using an interaction ID and requested changes.
3. **Fetch Interactions** — retrieves recent interactions, optionally filtered by HCP name.
4. **Summarize HCP** — creates an AI summary of the relationship and recent interaction history.
5. **Suggest Next Action** — recommends a compliant next step based on interaction history.

## Architecture

React/Redux -> FastAPI -> LangGraph Agent -> Groq LLM -> CRM Tools -> SQL Database

## Project Structure

```text
ai-first-crm-hcp/
├── backend/
│   ├── app/
│   │   ├── agent.py
│   │   ├── database.py
│   │   ├── main.py
│   │   ├── models.py
│   │   ├── schemas.py
│   │   └── tools.py
│   ├── .env.example
│   └── requirements.txt
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   ├── store/
│   │   ├── App.jsx
│   │   ├── main.jsx
│   │   └── styles.css
│   ├── .env.example
│   ├── index.html
│   ├── package.json
│   └── vite.config.js
└── README.md
```

## Backend Setup

```bash
cd backend
python -m venv venv
```

Windows:

```bash
venv\Scripts\activate
```

macOS/Linux:

```bash
source venv/bin/activate
```

Install dependencies:

```bash
pip install -r requirements.txt
```

Create environment file:

```bash
cp .env.example .env
```

Add your Groq API key to `.env`.

For the fastest local demo, leave `DATABASE_URL=sqlite:///./crm.db`. For the assignment requirement, use PostgreSQL or MySQL before final submission.

PostgreSQL example:

```env
DATABASE_URL=postgresql+psycopg2://postgres:password@localhost:5432/hcp_crm
```

MySQL example:

```env
DATABASE_URL=mysql+pymysql://root:password@localhost:3306/hcp_crm
```

Run:

```bash
uvicorn app.main:app --reload --port 8000
```

API docs: `http://localhost:8000/docs`

## Frontend Setup

```bash
cd frontend
npm install
cp .env.example .env
npm run dev
```

Open `http://localhost:5173`.

## Environment Variables

Backend:

```env
GROQ_API_KEY=your_new_groq_api_key
GROQ_MODEL=gemma2-9b-it
DATABASE_URL=sqlite:///./crm.db
FRONTEND_ORIGIN=http://localhost:5173
```

If the exact assignment model is unavailable in your Groq account, change only `GROQ_MODEL` to a currently available Groq chat model. For submission, follow the evaluator's requested model where available.

## Demo Prompts

### Log Interaction
`Log an interaction: Met Dr. Ananya Rao at Apollo Clinic today. Discussed CardioPlus. She was interested in efficacy data and asked for a follow-up next Friday.`

### Edit Interaction
`Edit interaction 1. Change the follow-up date to 2026-07-24 and sentiment to very interested.`

### Fetch
`Show interactions with Dr. Ananya Rao.`

### Summarize
`Summarize HCP Dr. Ananya Rao.`

### Suggest Next Action
`Suggest the next action for Dr. Ananya Rao.`

## Notes on AI Safety and Life-Sciences Use

The assistant is designed for CRM workflow support. It does not provide medical advice, prescribe treatments, or invent clinical claims. Human review is expected before CRM records or suggested actions are used operationally.

## Video Walkthrough Order

1. Explain the problem and architecture.
2. Show structured form logging.
3. Show conversational logging.
4. Demonstrate Edit Interaction.
5. Demonstrate Fetch Interactions.
6. Demonstrate Summarize HCP.
7. Demonstrate Suggest Next Action.
8. Show FastAPI docs and project structure.
9. Explain LangGraph routing and tool execution.
10. Conclude with how AI reduces manual CRM work.
