import json
from datetime import date
from typing import Optional
from langchain_core.tools import tool
from sqlalchemy import desc, func
from .database import SessionLocal
from .models import Interaction


def _serialize(item: Interaction) -> dict:
    return {
        "id": item.id,
        "hcp_name": item.hcp_name,
        "organization": item.organization,
        "interaction_type": item.interaction_type,
        "interaction_date": item.interaction_date.isoformat() if item.interaction_date else None,
        "products_discussed": item.products_discussed,
        "topics_discussed": item.topics_discussed,
        "sentiment": item.sentiment,
        "notes": item.notes,
        "ai_summary": item.ai_summary,
        "follow_up_date": item.follow_up_date.isoformat() if item.follow_up_date else None,
        "next_action": item.next_action,
    }


@tool
def log_interaction(
    hcp_name: str,
    interaction_date: str,
    notes: str,
    interaction_type: str = "Visit",
    organization: str = "",
    products_discussed: str = "",
    topics_discussed: str = "",
    sentiment: str = "",
    ai_summary: str = "",
    follow_up_date: str = "",
    next_action: str = "",
) -> str:
    """Log a new HCP interaction. Use this when the user wants to create/save/log an interaction."""
    db = SessionLocal()
    try:
        item = Interaction(
            hcp_name=hcp_name,
            organization=organization or None,
            interaction_type=interaction_type,
            interaction_date=date.fromisoformat(interaction_date),
            products_discussed=products_discussed or None,
            topics_discussed=topics_discussed or None,
            sentiment=sentiment or None,
            notes=notes,
            ai_summary=ai_summary or notes[:500],
            follow_up_date=date.fromisoformat(follow_up_date) if follow_up_date else None,
            next_action=next_action or None,
        )
        db.add(item)
        db.commit()
        db.refresh(item)
        return json.dumps({"status": "success", "message": "Interaction logged", "interaction": _serialize(item)})
    except Exception as exc:
        db.rollback()
        return json.dumps({"status": "error", "message": str(exc)})
    finally:
        db.close()


@tool
def edit_interaction(
    interaction_id: int,
    hcp_name: str = "",
    organization: str = "",
    interaction_type: str = "",
    interaction_date: str = "",
    products_discussed: str = "",
    topics_discussed: str = "",
    sentiment: str = "",
    notes: str = "",
    ai_summary: str = "",
    follow_up_date: str = "",
    next_action: str = "",
) -> str:
    """Edit an existing interaction by ID. Only non-empty values are changed."""
    db = SessionLocal()
    try:
        item = db.query(Interaction).filter(Interaction.id == interaction_id).first()
        if not item:
            return json.dumps({"status": "error", "message": f"Interaction {interaction_id} not found"})

        updates = {
            "hcp_name": hcp_name,
            "organization": organization,
            "interaction_type": interaction_type,
            "products_discussed": products_discussed,
            "topics_discussed": topics_discussed,
            "sentiment": sentiment,
            "notes": notes,
            "ai_summary": ai_summary,
            "next_action": next_action,
        }
        for field, value in updates.items():
            if value != "":
                setattr(item, field, value)

        if interaction_date:
            item.interaction_date = date.fromisoformat(interaction_date)
        if follow_up_date:
            item.follow_up_date = date.fromisoformat(follow_up_date)

        db.commit()
        db.refresh(item)
        return json.dumps({"status": "success", "message": "Interaction updated", "interaction": _serialize(item)})
    except Exception as exc:
        db.rollback()
        return json.dumps({"status": "error", "message": str(exc)})
    finally:
        db.close()


@tool
def fetch_interactions(hcp_name: str = "", limit: int = 10) -> str:
    """Fetch recent CRM interactions. Optionally filter by HCP name."""
    db = SessionLocal()
    try:
        query = db.query(Interaction)
        if hcp_name:
            query = query.filter(func.lower(Interaction.hcp_name).contains(hcp_name.lower()))
        items = query.order_by(desc(Interaction.interaction_date), desc(Interaction.id)).limit(min(limit, 25)).all()
        return json.dumps({"status": "success", "count": len(items), "interactions": [_serialize(i) for i in items]})
    finally:
        db.close()


@tool
def summarize_hcp(hcp_name: str) -> str:
    """Retrieve interaction history for one HCP so the AI can summarize the relationship."""
    db = SessionLocal()
    try:
        items = (
            db.query(Interaction)
            .filter(func.lower(Interaction.hcp_name).contains(hcp_name.lower()))
            .order_by(desc(Interaction.interaction_date))
            .limit(15)
            .all()
        )
        if not items:
            return json.dumps({"status": "not_found", "message": f"No interactions found for {hcp_name}"})
        return json.dumps({
            "status": "success",
            "instruction": "Summarize relationship, interests, objections, sentiment trend, and follow-ups using only this CRM history.",
            "interactions": [_serialize(i) for i in items],
        })
    finally:
        db.close()


@tool
def suggest_next_action(hcp_name: str) -> str:
    """Retrieve HCP history so the AI can recommend the next sales action."""
    db = SessionLocal()
    try:
        items = (
            db.query(Interaction)
            .filter(func.lower(Interaction.hcp_name).contains(hcp_name.lower()))
            .order_by(desc(Interaction.interaction_date))
            .limit(10)
            .all()
        )
        if not items:
            return json.dumps({"status": "not_found", "message": f"No interactions found for {hcp_name}"})
        return json.dumps({
            "status": "success",
            "instruction": (
                "Recommend one practical, compliant next action. Do not provide medical advice, "
                "invent claims, or recommend off-label promotion. Base the answer only on this history."
            ),
            "interactions": [_serialize(i) for i in items],
        })
    finally:
        db.close()


TOOLS = [
    log_interaction,
    edit_interaction,
    fetch_interactions,
    summarize_hcp,
    suggest_next_action,
]
