from fastapi import Depends, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from .agent import run_agent
from .database import Base, engine, get_db, settings
from .models import Interaction
from .schemas import ChatRequest, ChatResponse, InteractionCreate, InteractionOut, InteractionUpdate

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="AI-First CRM HCP API",
    description="FastAPI backend with LangGraph + Groq for HCP interaction management.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[settings.frontend_origin, "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
def root():
    return {"name": "AI-First CRM HCP API", "status": "running"}


@app.get("/health")
def health():
    return {"status": "healthy", "model": settings.groq_model}


@app.get("/interactions", response_model=list[InteractionOut])
def list_interactions(db: Session = Depends(get_db)):
    return db.query(Interaction).order_by(Interaction.id.desc()).all()


@app.post("/interactions", response_model=InteractionOut, status_code=201)
def create_interaction(payload: InteractionCreate, db: Session = Depends(get_db)):
    item = Interaction(**payload.model_dump())
    db.add(item)
    db.commit()
    db.refresh(item)
    return item


@app.put("/interactions/{interaction_id}", response_model=InteractionOut)
def update_interaction(interaction_id: int, payload: InteractionUpdate, db: Session = Depends(get_db)):
    item = db.query(Interaction).filter(Interaction.id == interaction_id).first()
    if not item:
        raise HTTPException(status_code=404, detail="Interaction not found")

    for key, value in payload.model_dump(exclude_unset=True).items():
        setattr(item, key, value)
    db.commit()
    db.refresh(item)
    return item


@app.delete("/interactions/{interaction_id}", status_code=204)
def delete_interaction(interaction_id: int, db: Session = Depends(get_db)):
    item = db.query(Interaction).filter(Interaction.id == interaction_id).first()
    if not item:
        raise HTTPException(status_code=404, detail="Interaction not found")
    db.delete(item)
    db.commit()


@app.post("/chat", response_model=ChatResponse)
def chat(payload: ChatRequest):
    try:
        return run_agent(payload.message)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))
