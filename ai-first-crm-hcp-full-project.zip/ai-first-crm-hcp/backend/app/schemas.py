from datetime import date, datetime
from typing import Optional
from pydantic import BaseModel, ConfigDict, Field


class InteractionCreate(BaseModel):
    hcp_name: str = Field(min_length=2)
    organization: Optional[str] = None
    interaction_type: str = "Visit"
    interaction_date: date
    products_discussed: Optional[str] = None
    topics_discussed: Optional[str] = None
    sentiment: Optional[str] = None
    notes: str = Field(min_length=2)
    ai_summary: Optional[str] = None
    follow_up_date: Optional[date] = None
    next_action: Optional[str] = None


class InteractionUpdate(BaseModel):
    hcp_name: Optional[str] = None
    organization: Optional[str] = None
    interaction_type: Optional[str] = None
    interaction_date: Optional[date] = None
    products_discussed: Optional[str] = None
    topics_discussed: Optional[str] = None
    sentiment: Optional[str] = None
    notes: Optional[str] = None
    ai_summary: Optional[str] = None
    follow_up_date: Optional[date] = None
    next_action: Optional[str] = None


class InteractionOut(InteractionCreate):
    id: int
    created_at: datetime
    updated_at: datetime
    model_config = ConfigDict(from_attributes=True)


class ChatRequest(BaseModel):
    message: str = Field(min_length=2)


class ChatResponse(BaseModel):
    response: str
    tool_used: Optional[str] = None
