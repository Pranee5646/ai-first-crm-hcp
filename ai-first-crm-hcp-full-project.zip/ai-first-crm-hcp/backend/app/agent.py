from datetime import date
from typing import Annotated, TypedDict
from langchain_core.messages import BaseMessage, HumanMessage, SystemMessage
from langchain_groq import ChatGroq
from langgraph.graph import END, StateGraph
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode
from .database import settings
from .tools import TOOLS


class AgentState(TypedDict):
    messages: Annotated[list[BaseMessage], add_messages]


SYSTEM_PROMPT = f"""
You are the AI assistant inside an AI-first life-sciences CRM for field representatives.
Today's date is {date.today().isoformat()}.

You manage HCP interaction workflows by selecting the correct CRM tool.

Available capabilities:
1. log_interaction: create a CRM interaction from natural-language notes.
2. edit_interaction: update a previously logged interaction by numeric ID.
3. fetch_interactions: retrieve interaction history.
4. summarize_hcp: retrieve history and then provide a concise relationship summary.
5. suggest_next_action: retrieve history and then recommend a compliant next action.

Rules:
- When the user clearly asks to perform one of these actions, call the appropriate tool.
- For logging, extract structured fields from the user's message. Create a concise ai_summary.
- Dates passed to tools must use YYYY-MM-DD. Resolve relative dates using today's date.
- Never invent an HCP name. If a required name or interaction ID is missing, ask for it.
- Never provide medical advice or invent clinical/product claims.
- After a tool returns, explain the result clearly and concisely.
- For summarize_hcp and suggest_next_action, use only the returned CRM history.
"""


def build_graph():
    if not settings.groq_api_key:
        raise RuntimeError("GROQ_API_KEY is missing. Add it to backend/.env")

    llm = ChatGroq(
        api_key=settings.groq_api_key,
        model=settings.groq_model,
        temperature=0.1,
    )
    model_with_tools = llm.bind_tools(TOOLS)

    def assistant_node(state: AgentState):
        response = model_with_tools.invoke([SystemMessage(content=SYSTEM_PROMPT), *state["messages"]])
        return {"messages": [response]}

    def route_after_assistant(state: AgentState):
        last = state["messages"][-1]
        return "tools" if getattr(last, "tool_calls", None) else END

    graph = StateGraph(AgentState)
    graph.add_node("assistant", assistant_node)
    graph.add_node("tools", ToolNode(TOOLS))
    graph.set_entry_point("assistant")
    graph.add_conditional_edges("assistant", route_after_assistant, {"tools": "tools", END: END})
    graph.add_edge("tools", "assistant")
    return graph.compile()


_graph = None


def run_agent(message: str) -> dict:
    global _graph
    if _graph is None:
        _graph = build_graph()

    result = _graph.invoke({"messages": [HumanMessage(content=message)]})
    messages = result["messages"]

    tool_used = None
    for msg in messages:
        if getattr(msg, "tool_calls", None):
            calls = msg.tool_calls
            if calls:
                tool_used = calls[-1].get("name")

    final_message = messages[-1]
    content = final_message.content
    if isinstance(content, list):
        content = " ".join(str(x) for x in content)

    return {"response": str(content), "tool_used": tool_used}
