from datetime import datetime
from sqlalchemy import Column, Date, DateTime, Integer, String, Text
from .database import Base


class Interaction(Base):
    __tablename__ = "interactions"

    id = Column(Integer, primary_key=True, index=True)
    hcp_name = Column(String(200), nullable=False, index=True)
    organization = Column(String(250), nullable=True)
    interaction_type = Column(String(80), nullable=False, default="Visit")
    interaction_date = Column(Date, nullable=False)
    products_discussed = Column(Text, nullable=True)
    topics_discussed = Column(Text, nullable=True)
    sentiment = Column(String(80), nullable=True)
    notes = Column(Text, nullable=False)
    ai_summary = Column(Text, nullable=True)
    follow_up_date = Column(Date, nullable=True)
    next_action = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
