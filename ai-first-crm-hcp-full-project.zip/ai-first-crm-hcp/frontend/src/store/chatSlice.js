import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";

const API = import.meta.env.VITE_API_URL || "http://localhost:8000";

export const sendChatMessage = createAsyncThunk("chat/send", async (message) => {
  const { data } = await axios.post(`${API}/chat`, { message });
  return { userMessage: message, ...data };
});

const slice = createSlice({
  name: "chat",
  initialState: {
    messages: [
      {
        role: "assistant",
        text: "Hi! I can log, edit, fetch, summarize HCP interactions, and suggest the next action. What would you like to do?",
      },
    ],
    loading: false,
    lastTool: null,
  },
  reducers: {
    addUserMessage: (state, action) => {
      state.messages.push({ role: "user", text: action.payload });
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(sendChatMessage.pending, (state) => { state.loading = true; })
      .addCase(sendChatMessage.fulfilled, (state, action) => {
        state.loading = false;
        state.lastTool = action.payload.tool_used;
        state.messages.push({
          role: "assistant",
          text: action.payload.response,
          tool: action.payload.tool_used,
        });
      })
      .addCase(sendChatMessage.rejected, (state, action) => {
        state.loading = false;
        state.messages.push({
          role: "assistant",
          text: `Error: ${action.error.message}. Check that the backend is running and GROQ_API_KEY is configured.`,
        });
      });
  },
});

export const { addUserMessage } = slice.actions;
export default slice.reducer;
