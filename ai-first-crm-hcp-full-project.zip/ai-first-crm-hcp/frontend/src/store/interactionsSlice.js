import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";

const API = import.meta.env.VITE_API_URL || "http://localhost:8000";

export const fetchInteractions = createAsyncThunk("interactions/fetch", async () => {
  const { data } = await axios.get(`${API}/interactions`);
  return data;
});

export const createInteraction = createAsyncThunk("interactions/create", async (payload) => {
  const { data } = await axios.post(`${API}/interactions`, payload);
  return data;
});

const slice = createSlice({
  name: "interactions",
  initialState: { items: [], loading: false, error: null },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchInteractions.pending, (state) => { state.loading = true; })
      .addCase(fetchInteractions.fulfilled, (state, action) => {
        state.loading = false;
        state.items = action.payload;
      })
      .addCase(fetchInteractions.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })
      .addCase(createInteraction.fulfilled, (state, action) => {
        state.items.unshift(action.payload);
      });
  },
});

export default slice.reducer;
