import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Activity, Bot, ClipboardPlus, History, Sparkles, Stethoscope } from "lucide-react";
import InteractionForm from "./components/InteractionForm";
import ChatPanel from "./components/ChatPanel";
import InteractionHistory from "./components/InteractionHistory";
import { fetchInteractions } from "./store/interactionsSlice";

export default function App() {
  const dispatch = useDispatch();
  const [mode, setMode] = useState("form");
  const [showHistory, setShowHistory] = useState(true);
  const lastTool = useSelector((s) => s.chat.lastTool);

  useEffect(() => {
    dispatch(fetchInteractions());
  }, [dispatch, lastTool]);

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark"><Stethoscope size={22} /></div>
          <div><strong>NovaCRM</strong><span>Life Sciences</span></div>
        </div>
        <nav>
          <button className="nav-item active"><Activity size={18} /> HCP Interactions</button>
          <button className="nav-item" onClick={() => setShowHistory(!showHistory)}>
            <History size={18} /> Interaction History
          </button>
        </nav>
        <div className="ai-status">
          <Sparkles size={18} />
          <div><strong>AI Agent Online</strong><span>LangGraph + Groq</span></div>
        </div>
      </aside>

      <main>
        <header className="topbar">
          <div>
            <p className="eyebrow">HCP MODULE</p>
            <h1>Log Interaction</h1>
            <p>Capture every HCP conversation with structured data or AI assistance.</p>
          </div>
          <div className="avatar">PS</div>
        </header>

        <section className="mode-switch">
          <button className={mode === "form" ? "selected" : ""} onClick={() => setMode("form")}>
            <ClipboardPlus size={18} /> Structured Form
          </button>
          <button className={mode === "chat" ? "selected" : ""} onClick={() => setMode("chat")}>
            <Bot size={18} /> AI Conversation
          </button>
        </section>

        <div className="content-grid">
          <section className="primary-card">
            {mode === "form" ? <InteractionForm /> : <ChatPanel />}
          </section>
          {showHistory && <InteractionHistory />}
        </div>
      </main>
    </div>
  );
}
