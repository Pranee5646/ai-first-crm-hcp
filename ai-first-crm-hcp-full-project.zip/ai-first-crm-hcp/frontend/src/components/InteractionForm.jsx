import { useState } from "react";
import { useDispatch } from "react-redux";
import { CalendarDays, Save } from "lucide-react";
import { createInteraction } from "../store/interactionsSlice";

const initial = {
  hcp_name: "",
  organization: "",
  interaction_type: "In-person Visit",
  interaction_date: new Date().toISOString().slice(0, 10),
  products_discussed: "",
  topics_discussed: "",
  sentiment: "Positive",
  notes: "",
  follow_up_date: "",
  next_action: "",
};

export default function InteractionForm() {
  const dispatch = useDispatch();
  const [form, setForm] = useState(initial);
  const [saved, setSaved] = useState(false);

  const update = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    const payload = { ...form };
    if (!payload.follow_up_date) payload.follow_up_date = null;
    await dispatch(createInteraction(payload)).unwrap();
    setSaved(true);
    setForm({ ...initial, interaction_date: new Date().toISOString().slice(0, 10) });
    setTimeout(() => setSaved(false), 2500);
  };

  return (
    <form onSubmit={submit}>
      <div className="section-title">
        <div><h2>Interaction Details</h2><p>Record the details of your HCP engagement.</p></div>
        <span className="badge"><CalendarDays size={14} /> CRM Record</span>
      </div>

      <div className="form-grid">
        <label>HCP Name<input required name="hcp_name" value={form.hcp_name} onChange={update} placeholder="e.g. Dr. Ananya Rao" /></label>
        <label>Organization<input name="organization" value={form.organization} onChange={update} placeholder="Hospital / Clinic" /></label>
        <label>Interaction Type
          <select name="interaction_type" value={form.interaction_type} onChange={update}>
            <option>In-person Visit</option><option>Phone Call</option><option>Video Call</option><option>Email</option><option>Conference</option>
          </select>
        </label>
        <label>Interaction Date<input required type="date" name="interaction_date" value={form.interaction_date} onChange={update} /></label>
        <label>Products Discussed<input name="products_discussed" value={form.products_discussed} onChange={update} placeholder="e.g. CardioPlus" /></label>
        <label>Sentiment
          <select name="sentiment" value={form.sentiment} onChange={update}>
            <option>Positive</option><option>Neutral</option><option>Interested</option><option>Needs Follow-up</option><option>Not Interested</option>
          </select>
        </label>
        <label className="full">Topics Discussed<input name="topics_discussed" value={form.topics_discussed} onChange={update} placeholder="Efficacy data, patient profile, product information..." /></label>
        <label className="full">Interaction Notes<textarea required rows="5" name="notes" value={form.notes} onChange={update} placeholder="Add detailed notes from the interaction..." /></label>
        <label>Follow-up Date<input type="date" name="follow_up_date" value={form.follow_up_date} onChange={update} /></label>
        <label>Next Action<input name="next_action" value={form.next_action} onChange={update} placeholder="Send approved material, schedule follow-up..." /></label>
      </div>

      <div className="form-actions">
        {saved && <span className="success">Interaction saved successfully.</span>}
        <button className="primary-btn" type="submit"><Save size={17} /> Save Interaction</button>
      </div>
    </form>
  );
}
