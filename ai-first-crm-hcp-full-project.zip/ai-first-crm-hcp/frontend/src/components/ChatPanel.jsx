import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Bot, Send, Sparkles, User } from "lucide-react";
import { addUserMessage, sendChatMessage } from "../store/chatSlice";

const prompts = [
  "Log an interaction with Dr. Ananya Rao",
  "Show my recent interactions",
  "Summarize HCP Dr. Ananya Rao",
  "Suggest the next action for Dr. Ananya Rao",
];

export default function ChatPanel() {
  const dispatch = useDispatch();
  const { messages, loading } = useSelector((s) => s.chat);
  const [input, setInput] = useState("");

  const send = async (text) => {
    const message = (text ?? input).trim();
    if (!message || loading) return;
    dispatch(addUserMessage(message));
    setInput("");
    dispatch(sendChatMessage(message));
  };

  return (
    <div className="chat">
      <div className="section-title">
        <div><h2>AI Interaction Assistant</h2><p>Use natural language to manage your HCP CRM workflow.</p></div>
        <span className="badge ai"><Sparkles size={14} /> 5 AI Tools</span>
      </div>

      <div className="prompt-chips">
        {prompts.map((p) => <button key={p} onClick={() => send(p)}>{p}</button>)}
      </div>

      <div className="messages">
        {messages.map((m, i) => (
          <div className={`message-row ${m.role}`} key={i}>
            <div className="message-icon">{m.role === "assistant" ? <Bot size={17} /> : <User size={17} />}</div>
            <div className="bubble">
              {m.tool && <span className="tool-pill">Tool: {m.tool.replaceAll("_", " ")}</span>}
              <p>{m.text}</p>
            </div>
          </div>
        ))}
        {loading && <div className="typing">AI agent is thinking and selecting a tool...</div>}
      </div>

      <div className="chat-input">
        <textarea value={input} onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }}
          placeholder="Example: Met Dr. Rao today and discussed CardioPlus..." />
        <button onClick={() => send()} disabled={loading}><Send size={18} /></button>
      </div>
    </div>
  );
}
