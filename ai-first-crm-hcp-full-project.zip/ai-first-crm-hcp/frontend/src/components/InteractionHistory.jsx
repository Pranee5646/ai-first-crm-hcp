import { useSelector } from "react-redux";
import { Clock3, MapPin } from "lucide-react";

export default function InteractionHistory() {
  const { items, loading } = useSelector((s) => s.interactions);

  return (
    <aside className="history-card">
      <div className="history-header"><div><h3>Recent Interactions</h3><p>Latest CRM activity</p></div><span>{items.length}</span></div>
      {loading && <p className="muted">Loading...</p>}
      <div className="history-list">
        {items.length === 0 && !loading && <div className="empty">No interactions yet. Log your first HCP interaction.</div>}
        {items.slice(0, 8).map((item) => (
          <article className="history-item" key={item.id}>
            <div className="history-top"><strong>{item.hcp_name}</strong><span>#{item.id}</span></div>
            <p>{item.ai_summary || item.notes}</p>
            <div className="meta">
              <span><Clock3 size={13} /> {item.interaction_date}</span>
              {item.organization && <span><MapPin size={13} /> {item.organization}</span>}
            </div>
            <div className="tags">
              <span>{item.interaction_type}</span>
              {item.sentiment && <span>{item.sentiment}</span>}
            </div>
          </article>
        ))}
      </div>
    </aside>
  );
}
